<?php
	/**
	* plugin name: Note
	* Description: Create Note.
	* Version: 1.0
	* Author: Poritosh David
	* Author URI: https://poritoshdavid.dev ;
	*/

	
	if( !defined('ABSPATH')) : exit(); endif;
	define( 'NOTE_PATH', trailingslashit( plugin_dir_path(__FILE__) ) );
	define( 'NOTE_URL', trailingslashit( plugins_url('/', __FILE__) ) );
	if( is_admin() ) {
		require_once NOTE_PATH . 'inc/functions/functions.php';
	    require_once NOTE_PATH . 'inc/setting.php';
	    
	}
		require_once NOTE_PATH . 'inc/users/usersetting.php';
		require_once NOTE_PATH . 'inc/users/path/path.php';

		function note_users($atts){
	
			if(is_user_logged_in()){
				
				ob_start();
			    include('inc/users/createNote.php');
			    return ob_get_clean();
			}
			return;
		     
			}
		add_shortcode('usernote', 'note_users');




