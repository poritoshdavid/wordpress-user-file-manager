<?php

wp_enqueue_script('notefunction', NOTE_URL . 'inc/functions/functions.js', array('jquery'),  rand(), true );
wp_localize_script('notefunction', 'NoteAdminAjax', array('ajaxurl' => admin_url('admin-ajax.php')));

require_once NOTE_PATH."inc/users/path/vendor/autoload.php";

function functionMoveFileAndFolders(){
	$getServerName = "public_html";
	$path = getcwd();
	$pathRefine = explode($getServerName,$path);
	$toFolder = $_POST['tofolder'];
	$fromFile = $_POST['fromfile'];
	if($toFolder == "home"){
		$toFolder = $pathRefine[0]."/".$getServerName."/NoteOpen";
	}
 	$move =  moveFolderWithFiles($fromFile, $toFolder);
   if($move){
      deleteFolderWithFiles($fromFile);
   }
   $successed = ["success", $toFolder];
	echo json_encode($successed);
	die();
	return true;
}
add_action('wp_ajax_functionMoveFileAndFolders', 'functionMoveFileAndFolders');
add_action('wp_ajax_nopriv_functionMoveFileAndFolders', 'functionMoveFileAndFolders');

function functionFolderBack(){
	$pathDir = getcwd();
	$path = $_POST['path'];
	$getServerName = "public_html"; // * remove (kim.com) ;
	$mainPathRefine = explode($getServerName,$pathDir);
	$pathRefine = explode($getServerName,$path);
	if(count($pathRefine) > 1){
		$prevPath = $mainPathRefine[count($mainPathRefine) - count($mainPathRefine)];
		$pathRef = $pathRefine[count($pathRefine) - 1];
		$pathEx = explode("/",$pathRef);
		$removePath = $pathEx[count($pathEx)-1];
		$margePath;
		foreach($pathEx as $mar){
			if($removePath != $mar){
				if(count($pathEx) > 2 && strlen($margePath) > 1 && strlen($mar)>1){
					$margePath .= "/". $mar ;
				}else{
					if(substr($margePath, -1) == "/"){
						$margePath .= $mar;
					}else{
							$margePath .= "/". $mar;
					}
					
				}	
			}
		}

		$mainPath = $prevPath."/".$getServerName."/".$margePath;

		if(is_dir($mainPath)){
			echo $mainPath;
		}else{
			echo "NoPath";
		}
	}else{
		echo "NoPath";
	}
	die();
	return true;
}
add_action('wp_ajax_functionFolderBack', 'functionFolderBack');
add_action('wp_ajax_nopriv_functionFolderBack', 'functionFolderBack');

function functionGetFileDownloadUrl(){
	$path =	functionGetDownloadPath();
	echo $path;
	die();
	return true;

}
add_action('wp_ajax_functionGetFileDownloadUrl', 'functionGetFileDownloadUrl');
add_action('wp_ajax_nopriv_functionGetFileDownloadUrl', 'functionGetFileDownloadUrl');


function functionGetDownloadPath(){
	$path = getcwd();
	$getServerName =  "public_html"; // * remove (kim.com) 
		$mainDomainServer = $_SERVER['SERVER_NAME'];
	if(strpos($path,$getServerName) !== false){
		$makePath =	explode($getServerName,$path);
		$path = $makePath[0].$getServerName;
	}
	$mainFolder = $path ."/UsersNoteDownloads";
	if(!is_dir($mainFolder)){
		mkdir($mainFolder);
		$mainFolder = $path ."/UsersNoteDownloads";
	}
	if(!is_dir($mainFolder."/download")){
		mkdir($mainFolder."/download");
	}
	if(is_file($mainFolder."/download/download.docx")){
		return $mainDomainServer."/UsersNoteDownloads/download/download.docx";
	}
	return "NO_URL";

}

function functionDownloadDocx(){
	$html = $_POST['html'];
	$getServerName = "public_html"; // * remove (kim.com) 
	$pw = new \PhpOffice\PhpWord\PhpWord();
	$section = $pw->addSection();
	\PhpOffice\PhpWord\Shared\html::addHtml($section, $html);
	$pathMaker = 	functionGetDownloadPath();
	$pw->save("../UsersNoteDownloads/download/download.docx","Word2007");
	die();
	return true;
}
add_action('wp_ajax_functionDownloadDocx', 'functionDownloadDocx');
add_action('wp_ajax_nopriv_functionDownloadDocx', 'functionDownloadDocx');

function functionsCreateFile(){
	global $wpdb;
	$fileName = $_POST['name'];
	$NoteDB = "wp_notePath";
	$getPath = $wpdb -> get_results("SELECT * FROM $NoteDB WHERE id = 1");
	$path;

	foreach ($getPath as $data) {
		$path = $data->textPath;
	}
	if(strlen($path)>3){
		$path = $path;
	}else{
		$path = functionGetMainPath();
	}
	
	if(is_dir($path)){
		$path = $path ."/".$fileName.".html";
	 file_put_contents($path,"");
	}else{
		$createPaths = explode("/",$path);
		$fileNameGet = $createPaths[count($createPaths)-1];
		$path = str_replace($fileNameGet,$fileName.".html",$path);
		file_put_contents($path,"");
	}

	die();
	return true;
}

add_action('wp_ajax_functionsCreateFile', 'functionsCreateFile');
add_action('wp_ajax_nopriv_functionsCreateFile', 'functionsCreateFile');

function functionCreateFolder(){
	global $wpdb;

	$folderName = $_POST['name'];
	$NoteDB = "wp_notePath";
	$getPath = $wpdb -> get_results("SELECT * FROM $NoteDB WHERE id = 1");
	$path;

	foreach ($getPath as $data) {
		$path = $data->textPath;
	}
	if(strlen($path)>3){
		$path = $path;
	}else{
		$path = functionGetMainPath();
	}
	
	if(is_dir($path)){
		$path = $path ."/".$folderName;
		mkdir($path);
	}else{
		$createPaths = explode("/",$path);
		$fileNameGet = $createPaths[count($createPaths)-1];
		$path = str_replace($fileNameGet,$folderName,$path);
		mkdir($path);
	}

	die();
	return true;
}

add_action('wp_ajax_functionCreateFolder', 'functionCreateFolder');
add_action('wp_ajax_nopriv_functionCreateFolder', 'functionCreateFolder');


function functionOpenFolders(){
	$folder = $_POST['path'];
	functionGetFolderAndFiles($folder);
	die();
	return true;
}

add_action('wp_ajax_functionOpenFolders', 'functionOpenFolders');
add_action('wp_ajax_nopriv_functionOpenFolders', 'functionOpenFolders');


function functionFetchFolderAndFiles(){
    $path = $_POST["path"];
    $getServerName = "public_html";
    $getDirName = "NoteOpen";
    $folder = functionGetMainPath();
    if($path != ""){
        if(is_dir($path)){
            $folder = $path;
        }
    }
	
	functionGetFolderAndFiles($folder);
	die();
	return true;
}


function functionGetMainPath(){

	$path = getcwd();
	$getServerName = "public_html"; // * remove (kim.com) 

	if(strpos($path,$getServerName) !== false){
		$makePath =	explode($getServerName,$path);
		$path = $makePath[0].$getServerName;
	}
	$mainFolder = $path ."/NoteOpen";
	if(!is_dir($mainFolder)){
		mkdir($mainFolder);
	}
	

	return $mainFolder;
}

function functionGetFolderAndFiles($path){
	$scanFiles = scandir($path);
	if(count($scanFiles)>2){
		$i = 0;
		$response = [];
		$listFile = [];
		$listFolder = [];
		foreach ($scanFiles as $value) {
			if($i != 0 && $i != 1){
				if(strpos($value, ".")){
					$nameFiles = explode(".",$value);
					$fileTime = date("m/d/y",filemtime($path."/".$value));
					$listDatas = ["file",$nameFiles[0],$path."/".$value,$fileTime ];
					array_push($listFile,$listDatas); 
				}else{
					$listDatas = ["folder",$value,$path."/".$value];
					array_push($listFolder, $listDatas);
				}	
			}
			$i++;
		}
		array_push($response,  $listFolder);
		array_push($response,  $listFile);
		echo json_encode($response);
		functionSetPat("");
	}else{
		$returnEmpty = ["empty"];
		echo json_encode($returnEmpty);
	}
}

add_action('wp_ajax_functionFetchFolderAndFiles', 'functionFetchFolderAndFiles');
add_action('wp_ajax_nopriv_functionFetchFolderAndFiles', 'functionFetchFolderAndFiles');

function functionGetFileContents(){
	$path = $_POST['path'];
	$content = file_get_contents($path,false);
	 echo $content;
	 functionSetPat($path);
	die();
	return true;
}
add_action('wp_ajax_functionGetFileContents', 'functionGetFileContents');
add_action('wp_ajax_nopriv_functionGetFileContents', 'functionGetFileContents');


function functionInFolders(){
	$path = $_POST['path'];
	 functionSetPat($path);
	die();
	return true;
}
add_action('wp_ajax_functionInFolders', 'functionInFolders');
add_action('wp_ajax_nopriv_functionInFolders', 'functionInFolders');

function functionGetPathName(){
	$userFolderName = "public_html";
	$path = $_POST['path'];
	$showPathUser = explode($userFolderName,$path);
	echo $userFolderName.$showPathUser[count($showPathUser)-1];
	die();
	return true;
}
add_action('wp_ajax_functionGetPathName', 'functionGetPathName');
add_action('wp_ajax_nopriv_functionGetPathName', 'functionGetPathName');

function functionSetPat($path){
	 global $wpdb;
	$userFolderName = "admin";
	$NoteDB = "wp_notePath";
	$checkDB = $wpdb -> Query("SELECT * FROM $NoteDB");
	if(!$checkDB && is_bool($checkDB)){
	 	$wpdb->Query("CREATE TABLE $NoteDB(id INT(20) AUTO_INCREMENT, textPath TEXT, userName TEXT, PRIMARY KEY(id))");
	 	$wpdb -> insert(
            $NoteDB,
            [
               "textPath" =>  $path,
               "userName"=>$userFolderName
            ]
        );
    }else{
	    $result = $wpdb->get_results("SELECT * FROM $NoteDB WHERE userName = '$userFolderName'");
	    if(strlen($userFolderName)>=2){
	          if(count($result) == 0){
	    		$wpdb -> insert(
	            $NoteDB,
	            [
	               "textPath" =>  $path,
	               "userName"=>$userFolderName
	            ]
	        );
	    }else{
	    	 $id;
		    foreach($result as $rst){
		    	$id = $rst->id;
		    }
	    	$wpdb -> update(
	            $NoteDB,
	            [
	               "textPath" =>  $path,
	               "userName"=>$userFolderName
	            ],
	            [
	            	"id" => $id
	            ]
	        );
	    }
     
	    }
	
    }

}
function functionIsPathReady(){
	global $wpdb;
	$NoteDB = "wp_notePath";
	$getPath = $wpdb->get_results("SELECT * FROM $NoteDB WHERE userName = 'admin'");
	$path;
	foreach ($getPath as $data) {
		$path = $data->textPath;
	}
	if(strlen($path) > 3){
		if(is_file($path)){
			$readyPath = ["ready", $path];
			echo json_encode($readyPath);
		}
		else{
			$readyPath = ["readyFolder", $path];
			echo json_encode($readyPath);
		}
	
	}else{
		$readyPath = ["nofld", $path];
		echo json_encode($readyPath);
	}
	die();
	return true;
}
add_action('wp_ajax_functionIsPathReady', 'functionIsPathReady');
add_action('wp_ajax_nopriv_functionIsPathReady', 'functionIsPathReady');




function functionSaveFile(){
	global $wpdb;
	$getContent = $_POST['htmlData'];
	$fileName = $_POST['fileName'];
	$NoteDB = "wp_notePath";
	$getPath = $wpdb -> get_results("SELECT * FROM $NoteDB WHERE id = 1");
	$path;
	foreach ($getPath as $data) {
		$path = $data->textPath;
	}	
	if(strlen($path) > 3){
		$filePath;
		if(!is_dir($path)){
			$modifyPath = explode("/",$path);
			$fileNameGet = $modifyPath[count($modifyPath)-1];
			$filePath = str_replace($fileNameGet,$fileName.".html",$path);
		}else{
			$filePath = $path;
		}
		
		if(is_file($filePath)){
			$matchPath = ["replace",$filePath];
			echo json_encode($matchPath);
		}else{
			file_put_contents($filePath."/".$fileName.".html", $getContent);
			$matchPath = ["new",$filePath];
			echo json_encode($matchPath);
		}
		
	}else{
		$folderPath = functionGetMainPath();
		$addPath = $folderPath."/".$fileName.".html";
		if(file_exists($addPath)){
			$matchPath = ["replace",$addPath];
			echo json_encode($matchPath);
		}else{
			file_put_contents($addPath, $getContent);
			$matchPath = ["new",$addPath];
			echo json_encode($matchPath);
		}
	}
	
	die();
	return true;
}
add_action('wp_ajax_functionSaveFile', 'functionSaveFile');
add_action('wp_ajax_nopriv_functionSaveFile', 'functionSaveFile');

function functionFileSaveConfirm(){
	$getContent = $_POST['htmlData'];
	$getPath = $_POST['path'];
	$getContent = stripcslashes($getContent);
	file_put_contents($getPath, $getContent);
	die();
	return true;
}
add_action('wp_ajax_functionFileSaveConfirm', 'functionFileSaveConfirm');
add_action('wp_ajax_nopriv_functionFileSaveConfirm', 'functionFileSaveConfirm');
