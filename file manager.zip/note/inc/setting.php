<?php


function note_setting_menu() {

    $hook = add_menu_page(
        'Note',
        'Note',
        'manage_options',
        'note-settings',
        'note_show',
        'dashicons-welcome-edit-page',
        6
    );

    add_action( 'admin_head-'.$hook, 'note_admin_styles_and_scripts');
}
add_action('admin_menu', 'note_setting_menu');


function note_admin_styles_and_scripts() {
    wp_register_style( 'note-image-uplaoder', NOTE_URL . 'css/image-uploader.css', '', rand() );
    wp_enqueue_style( 'note-style', NOTE_URL . 'css/noteEditor.css', '', rand());

    wp_enqueue_style( 'note-folder-style', NOTE_URL . 'css/folder.css', '', rand());



    wp_register_script( 'note-image-uploader', NOTE_URL . 'js/image-uploader.js', array('jquery'), rand(), true );
    wp_enqueue_script( 'note-script', NOTE_URL . 'js/noteEditor.js', array('jquery'), rand(), false );
    wp_enqueue_script( 'note-sizings', NOTE_URL . 'js/imageResize.js', array('jquery'), rand(), true );
   


}
add_action( 'wp_enqueue_scripts', 'note_admin_styles_and_scripts' );  
add_action( 'admin_enqueue_scripts', 'note_admin_styles_and_scripts' );
function note_show(){
    ?>

    <div class="fileName"></div>
    <div id="editor" class="pell"></div>
    <div id="saveEditor">
        <button class="saveFile" type="button">Save</button>
    </div>
    <div id="folders" class="folder">
        <div>
            <div>
                <button id = "createNote" type="button">Create New Note</button>
                <button id = "createFolder" type="button">Create New Folder</button>
            </div>
        </div>
      <div class="showDir">
      </div>
  
      <div style="display: inline-block;" class="pst"></div>
        <div id="fileAndFolder"></div>
    </div>    

    <style type="text/css">
      .pell-content > img{
            height:250px;
            width:300px;
        }
        .pell-content > a{
            text-decoration: underline;
            color:red;
        }
          
      @media print{
         body{
          visibility: hidden;
        }
        .pell-content{
          visibility: visible !important;
          position: absolute;
          top: 0;
          left: 0;
        }
     
      }
    </style>
    <script>
      var editor = window.pell.init({
        element: document.getElementById('editor'),
        actions: ['bold', 'italic', 'underline','paragraph', 'heading1', 'heading2', 'olist', 'ulist', 'link','unlink', 'image', 'justifyLeft', 'justifyRight', 'justifyCenter', 'justifyFull'],
        defaultParagraphSeparator: 'p',
        onChange: function (html) {
           var span = document.getElementsByTagName("span");
           var img = document.getElementsByTagName("img");
          for(var i = 0; i<span.length;i++){
            span[i].removeAttribute("style");
          }
          for(var i = 0; i<img.length;i++){
            img[i].style.removeProperty("font-family");
            img[i].style.removeProperty("background-color");
            img[i].style.removeProperty("font-size");
            img[i].style.removeProperty("color");
          }
        }
      });
    </script> 
    <?php
}