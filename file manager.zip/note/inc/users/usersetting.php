<?php


add_action( 'wp_enqueue_scripts', 'note_user_styles_and_scripts' );function note_user_styles_and_scripts() {

    wp_enqueue_style( 'note-image-uplaoder', NOTE_URL . 'css/image-uploader.css', '', rand() );
    wp_enqueue_style( 'note-style', NOTE_URL . 'css/noteEditor.css', '', rand());
    wp_enqueue_style( 'note-folder-style', NOTE_URL . 'css/folder.css', '', rand());



    wp_enqueue_script( 'note-image-uploader', NOTE_URL . 'js/image-uploader.js', array('jquery'), rand(), true );
    wp_enqueue_script( 'note-script', NOTE_URL . 'js/noteEditor.js', array('jquery'), rand(), false );
    wp_enqueue_script( 'note-sizing-editor', NOTE_URL . 'js/imageResize.js', array('note-script'), rand(), true );

}  
