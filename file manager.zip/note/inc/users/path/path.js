;
(function($) {
    $(document).ready(function() {
        onLoad("");
        function onLoad(path) {
            $.ajax({
                type: 'POST',
                url: NoteAjax.ajaxurl,
                data: {
                    action: "fetchFolderAndFiles",
                    "path":path
                },
                success: function(v) {
                     var response;
                    try{
                        response = JSON.parse(v);
                    }catch(e){
                        console.log("");
                    }
                  
                    if (response.length != 0) {
                       
                        fileAndFolders(response);
                    }
                },
                error: function(e) {
                    console.log(e);
                }

            });
        }
        
           
    
        // main funtion run
        var save = $(".saveFile");
        var createFile = $("#createNote");
        var createFolder = $("#createFolder");
        var contentsMoveCopy;
        var mcPath;
        var currentFolderPath;
        var nowGet = true;
        var movingPath;
        
        createFile.on("click", function() {
            $(document.body).append('<div class="createNeFile"><div style="text-align: start">File Name</div><div><input type="text" class="fileInsertName" placeholder="Enter file name"></div><div style="margin-top:20px"><button type="button" class="cancelCreateFile" style="margin-right:5px;display:inline-block;cursor:pointer;">Cancel</button><button type="button" class="createNFile" style="margin-left:5px;display:inline-block;cursor:pointer;">Ok</button></div></div>');
            var fileCancel = $(".cancelCreateFile");
            var fileOk = $(".createNFile");
            fileCancel.on("click", function() {
                $(".createNeFile").remove();
            })

            fileOk.on("click", function() {
                var nameFile = $(".fileInsertName").val();
                if (nameFile.length > 1) {
                    $.ajax({
                        type: 'POST',
                        url: NoteAjax.ajaxurl,
                        data: {
                            action: "createFile",
                            "name": nameFile
                        },
                        success: function(v) {
                            onLoad("");
                        },
                        error: function(e) {
                            console.log(e);
                        }

                    });
                }
                $(".createNeFile").remove();

            });
        });
        createFolder.on("click", function() {

            $(document.body).append('<div class="createNeFolder"><div style="text-align: start">Folder</div><div><input type="text" class="folderNameInsert" placeholder="Enter folder name"></div><div style="margin-top:20px"><button type="button" class="cancelCreateFolder" style="margin-right:5px;display:inline-block;cursor:pointer;">Cancel</button><button type="button" class="createNewFolder" style="margin-left:5px;display:inline-block;cursor:pointer;">Ok</button></div></div>');
            var folderCancel = $(".cancelCreateFolder");
            var folderOk = $(".createNewFolder");
            folderCancel.on("click", function() {
                $(".createNeFolder").remove();
            })

            folderOk.on("click", function() {
                var nameFolder = $(".folderNameInsert").val();
                if (nameFolder.length > 1) {
                    $.ajax({
                        type: 'POST',
                        url: NoteAjax.ajaxurl,
                        data: {
                            action: "createFolder",
                            "name": nameFolder
                        },
                        success: function(v) {
                           onLoad("");
                        },
                        error: function(e) {
                            console.log(e);
                        }

                    });
                }
                $(".createNeFolder").remove();

            });


        });


        save.on("click", function() {
            var cont = $(".pell-content");
            var dataHtml = cont.html();
            $.ajax({
                type: 'GET',
                url: NoteAjax.ajaxurl,
                data: {
                    action: "isPathReady",
                },
                success: function(isReady) {
                    
                    var dataReady = JSON.parse(isReady);
                    if (dataReady[0] == "ready") {
                        saveDir(dataReady[1], dataHtml);
                    } else {
                        $(document.body).append('<div class="fileSaveAlert"><div style="text-align: start">Save As</div><div><input type="text" class="fileNameInsert" placeholder="Enter file name"></div><div style="margin-top:20px"><button type="button" class="cancelCreate" style="margin-right:5px;display:inline-block;cursor:pointer;">Cancel</button><button type="button" class="createNewFile" style="margin-left:5px;display:inline-block;cursor:pointer;">Ok</button></div></div>');
                        var submitOK = $(".createNewFile");
                        var submitCancel = $(".cancelCreate");
                        submitCancel.on("click", function() {
                            $(".fileSaveAlert").remove();
                        });
                        submitOK.on("click", function() {
                            var fileName = $(".fileNameInsert");
                            if (dataHtml.length > 1 && fileName.val().length > 1) {
                                $.ajax({
                                    type: 'POST',
                                    url: NoteAjax.ajaxurl,
                                    data: {
                                        action: "saveFile",
                                        "htmlData": dataHtml,
                                        "fileName": fileName.val()
                                    },
                                    success: function(v) {
                               
                                        var data = JSON.parse(v);
                                        if (data[0] == "replace") {
                                            var confirmData = confirm("Do you want to replace file?");
                                            if (confirmData) {
                                                saveDir(data[1], dataHtml);
                                            }
                                        } else {

                                           onLoad("");
                                        }

                                    },
                                    error: function(e) {
                                        console.log(e);
                                    }

                                });
                            }
                            $(".fileSaveAlert").remove();
                        });
                    }
                },
                error: function(e) {
                    console.log(e);
                }

            });
        });


        function saveDir(path, data) {
            var dataRep;
            try{
               dataRep = data.replaceAll('&nbsp;', ""); 
            }catch(e){}
            if(dataRep != null){
                data = dataRep;
            }
            $(document.body).append('<div class="saveNotice" style="position:fixed;top:30%; left:30%; z-index:9999;"><div>Save Successfully</div></div>')
            $.ajax({
                type: 'POST',
                url: NoteAjax.ajaxurl,
                data: {
                    action: "fileSaveConfirm",
                    'path': path,
                    'htmlData': data
                },
                success: function(v) {
                    $(".saveNotice").remove();
                    // reload();
                },
                error: function(e) {
                    console.log(e);
                }

            });
        }



        function fileAndFolders(response) {
            var elm = $("#fileAndFolder");
            elm.empty();
            response.forEach(function(item, i) {
                if (i == 0) {
                       if(item != "empty"){
                         item.forEach(function(items, k) {
                            createFolderData(items, elm);
                        });
                    }
                } else {
                    item.forEach(function(items, k) {
                        createFileData(items, elm);
                    });
                }

            });


            var itemFile = $(".fileSelect");
            var itemFolder = $(".folderSelect");
            var itemFileMove = $(".fileMove");
            var itemFolderMove = $(".folderMove");
            var itemFolder = $(".folderSelect");
            var deleteFile = $(".deleteFile");
            var deleteFolder = $(".deleteFolder");
            var downloadDoc = $(".downloadDoc");
            if (downloadDoc.length != 0) {
                downloadDoc.on("click", function(e) {
                    var currentElm = e.currentTarget.parentElement;
                    var type = $(currentElm.parentElement).attr("type");
                    var parentElm = currentElm.parentElement;
                    var prevParentElm = parentElm.parentElement;
                    var index = Array.prototype.indexOf.call(prevParentElm.children, parentElm);
                    docxDownload(type, index, response);
                });
            }


             if (deleteFile.length != 0) {
                deleteFile.on("click", function(e) {
                    var currentElm = e.currentTarget.parentElement;
                    var type = $(currentElm.parentElement).attr("type");
                    var parentElm = currentElm.parentElement;
                    var prevParentElm = parentElm.parentElement;
                    var index = Array.prototype.indexOf.call(prevParentElm.children, parentElm);
                    var prefLength = response[0].length;
                    var path = response[1][index - prefLength];
                  
                    deleteFolderAndFiles(path[2]);

                });
            }



            if (itemFolder.length != 0) {
                itemFolder.css("cursor", "pointer");
                itemFolder.click(function(e) {
                    var type = $(e.currentTarget.parentElement).attr("type");
                    var parentElm = e.currentTarget.parentElement;
                    var prevParentElm = parentElm.parentElement;
                    var index = Array.prototype.indexOf.call(prevParentElm.children, parentElm);
                    fileAndFolderOpen($(".itemFolder"), type, index, response);
                });

            }
           if (itemFileMove.length != 0) {
                itemFileMove.on("click", function(elp) {
                    openMainFolder("");
                    var type = $(elp.currentTarget.parentElement).attr("type");
                    var parentElm = elp.currentTarget.parentElement;
                    var prevParentElm = parentElm.parentElement;
                    var index = Array.prototype.indexOf.call(prevParentElm.children, parentElm);
                    var prefLength = response[0].length;
                    var path = response[1][index - prefLength];
                    movePath = path[2];
                });
            }
            if (itemFolderMove.length != 0) {
                itemFolderMove.on("click", function(elp) {
                    openMainFolder("");
                    var type = $(elp.currentTarget.parentElement).attr("type");
                    var parentElm = elp.currentTarget.parentElement;
                    var prevParentElm = parentElm.parentElement;
                    var index = Array.prototype.indexOf.call(prevParentElm.children, parentElm);
                    var path = response[0][index];
                    movePath = path[2];
                });
            }
            if (deleteFolder.length != 0) {
                deleteFolder.css("cursor", "pointer");
                deleteFolder.on("click", elp => {
                    var type = $(elp.currentTarget.parentElement).attr("type");
                    var parentElm = elp.currentTarget.parentElement;
                    var prevParentElm = parentElm.parentElement;
                    var index = Array.prototype.indexOf.call(prevParentElm.children, parentElm);
                    var path = response[0][index];
                    deleteFolderAndFiles(path[2]);
                });

            }
            
            if (itemFile.length != 0) {
                itemFile.css("cursor", "pointer");
                
                itemFile.on("click", function(e) {
                 
                        var type = $(e.currentTarget.parentElement).attr("type");
                        var parentElm = e.currentTarget.parentElement;
                        var prevParentElm = parentElm.parentElement;
                        var index = Array.prototype.indexOf.call(prevParentElm.children, parentElm);
                        fileAndFolderOpen(parentElm, type, index, response);
                 
                 

                });

            }

        }
        
         function deleteFolderAndFiles(path) {
      
            $.ajax({
                type: 'POST',
                url: NoteAjax.ajaxurl,
                data: {
                    action: "deleteFile",
                    'path': path,
                },
                success: function(v) {
                 
                    if (v == "success") {
                        onLoad("");
                    }
                },
                error: function(e) {
                    console.log(e);
                }
            });

        }

        function openMainFolder(path) {
            $.ajax({
                type: 'POST',
                url: NoteAjax.ajaxurl,
                data: {
                    action: "fetchFolderAndFiles",
                    "path": path
                },
                success: function(v) {
                    if (v.length != 0) {
                        var response = JSON.parse(v);
                        try {
                            $(".closeFM").remove();
                        } catch (e) {}
                        $(document.body).prepend('<div class="closeFM" id="closeFileManager"style="padding:10px 10px;width:50%;height:300px;overflow-y: auto;background:#d0d0d0;position:fixed;top:30%;left:25%;"><div style="display: flex;justify-content: space-between;width: 100%; padding: 0 10px;"><div id="pastFileFolder"style="border:1px solid #000;cursor:pointer; padding:0 5px;">paste</div><div id="closeManager" style="cursor:pointer;padding:0 5px;">X</div></div><div id="moveFolderManger"></div></div>');
                        var elm = $("#moveFolderManger");
                        response.forEach(function(items, i) {
                            if (i == 0) {
                                if (items == "empty") {
                                    elm.append("<div id ='noFiles'style='text-align:center'>there is no folder</div>");
                                } else {
                                    try {
                                        $("#noFiles").remove();
                                    } catch (e) {}
                                    items.forEach(function(items, k) {
                                        createFolders(items, elm);
                                    });
                                }

                            }

                        });
                        $("#closeManager").on("click", function(e) {
                            $("#closeFileManager").remove();
                        });
                        $("#pastFileFolder").on("click", function(e) {
                            if (movePath != null && movingPath != null) {
                                moveFileFolders(movePath, movingPath);
                            } else if (movePath != null) {
                                moveFileFolders(movePath, "home");
                            }
                        });
                        $(".moveItems").on("click", function(elms) {
                            var parent = elms.currentTarget.parentElement;
                            var parents = parent.parentElement;
                            var index = Array.prototype.indexOf.call(parents.children, parent);
                            $(".itemMoveFolder").remove();
                            var path = response[0][index];
                            movingPath = path[2];
                            openMainFolder(path[2]);
                        })
                    }
                },
                error: function(e) {
                    console.log(e);
                }

            });
        }

        function createFolders(responseMove, element) {
            element.append('<div type="' + responseMove[0] + '" class="itemMoveFolder"><div class="moveItems" style="cursor:pointer;display:inline-block;width:40%;"><h5  style="margin-bottom:5px">' + responseMove[1] + '</h5></div><div style="display:inline-block;width:40%;"><p  style="margin-bottom:5px">' + responseMove[0] + '</p></div></div>');
        }

        function moveFileFolders(fromFile, toFolder) {

            $.ajax({
                type: 'POST',
                url: NoteAjax.ajaxurl,
                data: {
                    action: "moveFileAndFolders",
                    'fromfile': fromFile,
                    'tofolder': toFolder
                },
                success: function(v) {
                    v = JSON.parse(v);
                    if (v[0] == "success") {
                        $(".closeFM").remove();
                        onLoad("");
                    }
                },
                error: function(e) {
                    console.log(e);
                }
            });
        }

        //---------------------


        function docxDownload(type, index, response) {
            if (type == "file") {
                var prefLength = response[0].length;
                var path = response[1][index - prefLength];
                $.ajax({
                    type: 'POST',
                    url: NoteAjax.ajaxurl,
                    data: {
                        action: "getFileContents",
                        'path': path[2],
                    },
                    success: function(v) {
                        $(".pell-content").html(v);
                        if (v.length > 0) {
                            $.ajax({
                                type: 'POST',
                                url: NoteAjax.ajaxurl,
                                data: {
                                    action: "downloadDocx",
                                    'html': v,
                                },
                                success: function(vi) {
                                    $.ajax({
                                        type: 'GET',
                                        url: NoteAjax.ajaxurl,
                                        data: {
                                            action: "getFileDownloadUrl",
                                        },
                                        success: function(vij) {
                                         
                                            if (vij != "NO_URL") {
                                                $(document.body).append('<a id="downloadFileDocx" download="" href="https://'+vij+'"></a>');
                                                $("#downloadFileDocx")[0].click();
                                                $("#downloadFileDocx").remove();
                                            }
                                        
                                        },
                                        error: function(e) {
                                            console.log(e);
                                        }

                                    });
                                },
                                error: function(e) {
                                    console.log(e);
                                }

                            });
                        }

                    },
                    error: function(e) {
                        console.log(e);
                    }

                });
                getPathNameUser(path[2]);

            }
        }

        function fileAndFolderOpen(element, type, index, response) {
            if (type == "folder") {
                element.remove();
                var path = response[0][index];
             
               OpenFolderWithPath(path[2]);
            } else {
                var prefLength = response[0].length;
                var path = response[1][index - prefLength];
                
                $.ajax({
                    type: 'POST',
                    url: NoteAjax.ajaxurl,
                    data: {
                        action: "getFileContents",
                        'path': path[2],
                    },
                    success: function(v) {
                        $(".pell-content").html(v);
                    },
                    error: function(e) {
                        console.log(e);
                    }

                });
                getPathNameUser(path[2]);

            }
        }

        function OpenFolderWithPath(path){
             $.ajax({
                    type: 'POST',
                    url: NoteAjax.ajaxurl,
                    data: {
                        action: "openFolders",
                        'path': path
                    },
                    success: function(v) {
                        if (v.length != 0) {
                            var response = JSON.parse(v);
                              var elm = $("#fileAndFolder");
                            if (response[0] != "empty") {
                                elm.empty();
                                fileAndFolders(response);
                            } else {
                                elm.append('<div style="text-align:center">There is no file and Folders</div>')
                            }
                            $.ajax({
                                type: 'POST',
                                url: NoteAjax.ajaxurl,
                                data: {
                                    action: "inFolders",
                                    'path': path,
                                },
                                success: function(v) {

                                },
                                error: function(e) {
                                    console.log(e);
                                }
                            });
                            getPathNameUser(path);
                        }
                    },
                    error: function(e) {
                        console.log(e);
                    }

                });
        }

        function getPathNameUser(path) {
     
            $.ajax({
                type: 'POST',
                url: NoteAjax.ajaxurl,
                data: {
                    action: "getPathName",
                    "path": path
                },
                success: function(v) {
                   var showDirectory = v.replace("html","docx");
                    $('.showDir').empty();
                    $('.showDir').prepend("<div class='folderBack' url="+v+" style='display:inline-block'>&lArr;</div>");
                    // $(".showDir").append("<p style='display:inline-block'>"+showDirectory+"</p>");
                    nowGet = true;
                    currentFolderPath = v;
                      var folderBack = $(".folderBack");
                        folderBack.on("click",function(e){
                             nowGet = false;        
                           var currentPath = $(e.currentTarget).attr("url");
                            var pathCheck = currentPath.split("/");
                          
                            if(pathCheck.length >= 2){
                                $.ajax({
                                    type: 'POST',
                                    url: NoteAjax.ajaxurl,
                                    data: {
                                        action: "folderBack",
                                        'path': currentPath,
                                    },
                                    success: function(v) {
                                  
                                       if(v != "NoPath"){
                                          OpenFolderWithPath(v);
                                       }
                                    },
                                    error: function(e) {
                                        console.log(e);
                                    }
                                }); 
                            }
                        });
                },
                error: function(e) {
                    console.log(e);
                }
            });
        }

        function createFileData(response, element) {
         
                //print Docx;
             // <div style="display:inline-block;" class="printDoc"><span style="vertical-align: text-bottom;">🖶</span></div>
            element.append('<div type="' + response[0] + '" class="itemFolder"><div class="noteFile" style="display:inline-block;width:36%;"><h5  style="margin-bottom:5px">' + response[1] + '</h5></div><div style="display:inline-block;width:10%;"><p  style="margin-bottom:5px">' + response[0] + '</p></div><div  class = "fileSelect"  style="display:inline-block;    border: 1px solid;padding: 0 5px;margin:0 5px;border-radius: 5px; cursor:pointer;"><h6 style="margin-bottom:0">Edit</h6></div><div  class = "fileMove"  style="display:inline-block;    border: 1px solid;padding: 0 5px;margin:0 5px; border-radius: 5px; cursor:pointer;"><h6  style="margin-bottom:0">Move</h6></div><div class="optionDown" style="display:inline-block;width:20%;"><div class="downloadDoc" style="display:inline-block;"><span style="vertical-align:middle;margin-right:5px;"  class="dashicons dashicons-download"></span></div><div  style="display:inline-block; margin-left:5px;vertical-align:middle; cursor:pointer" class="deleteFile"><span class="dashicons dashicons-trash"></span></div></div><div style="width:15%; display:inline-block;"><p  style="margin-bottom:5px">'+response[3]+'</p></div></div>');
        }

        function createFolderData(response, element) {
            element.append('<div type="' + response[0] + '" class="itemFolder"><div class = "folderSelect" style="display:inline-block;width:36%;"><span style="display:inline-block; vertical-align:baseline;" class="dashicons dashicons-open-folder"></span><h5 style="display:inline-block; margin-bottom:5px">' + response[1] + '</h5></div><div style="display:inline-block;width:10%;"><p  style="margin-bottom:5px">' + response[0] + '</p></div><div  class = "folderMove"  style="display:inline-block;    border: 1px solid;padding: 0 5px;margin:0 5px; border-radius: 5px; cursor:pointer;"><h6  style="margin-bottom:0">Move</h6></div><div  style="display:inline-block; margin-left:5px;vertical-align:baseline; cursor:pointer" class="deleteFolder"><span class="dashicons dashicons-trash"></span></div></div>');
        }

       

    });
})(jQuery);