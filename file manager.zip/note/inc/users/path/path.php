<?php

wp_enqueue_script('npJs', NOTE_URL . 'inc/users/path/path.js', array('jquery'),  rand(), true );
wp_localize_script('npJs', 'NoteAjax', array('ajaxurl' => admin_url('admin-ajax.php')));

require "vendor/autoload.php";
require "vendor/phpoffice/phpword/src/PhpWord/Shared/Html.php";

function deleteFile(){
	$path = $_POST["path"];
	deleteFolderWithFiles($path); 
	echo "success";
	die();
	return true;
}
add_action('wp_ajax_deleteFile', 'deleteFile');
add_action('wp_ajax_nopriv_deleteFile', 'deleteFile');

function moveFileAndFolders(){
	global $current_user;
	$userFolderName = $current_user->user_login;
	$getServerName = "public_html";
	$path = getcwd();
	$pathRefine = explode($getServerName,$path);
	$toFolder = $_POST['tofolder'];
	$fromFile = $_POST['fromfile'];
	if($toFolder == "home"){
		$toFolder = $pathRefine[0]."/".$getServerName."/NoteOpen"."/".$userFolderName;
	}
 	$move =  moveFolderWithFiles($fromFile, $toFolder);
   if($move){
      deleteFolderWithFiles($fromFile);
   }
   $successed = ["success", $toFolder];
	echo json_encode($successed);
	die();
	return true;
}
add_action('wp_ajax_moveFileAndFolders', 'moveFileAndFolders');
add_action('wp_ajax_nopriv_moveFileAndFolders', 'moveFileAndFolders');

  function deleteFolderWithFiles($source){
      if(is_dir($source)){
            $files = scandir($source);
            foreach($files as $file){
               if($file != "." && $file != ".."){
                  $sourceFile = $source."/".$file;
                  if(is_dir($sourceFile)){
                   deleteFolderWithFiles($sourceFile);
                  }else{
                     if(is_file($sourceFile)){
                        unlink($sourceFile);
                     }
                  }
               
               }
               
            }
            $count = count(glob($source ."/*"));
               if($count == 0){
                  rmdir($source);
               }

            
         }else{
            if(is_file($source)){
               unlink($source);
            }
         }
   }

   function moveFolderWithFiles($source, $target){
         if(is_dir($source)){
	         $sourceBase = basename($source);
	         $targetBase = basename($target);
	         if($sourceBase != $targetBase){
	            $target = $target."/".$sourceBase;
	            if(!is_dir($target)){
	               mkdir($target);
	            }
	         }
         }
         if(is_dir($source) && is_dir($target)){
            $files = scandir($source);
            foreach($files as $file){
               if($file != "." && $file != ".."){

                  $targetFile = $target."/".$file;
                  $sourceFile = $source."/".$file;

                  if(is_dir($sourceFile)){
                     if(!is_dir($targetFile)){
                        mkdir($targetFile);
                     }
                     moveFolderWithFiles($sourceFile,$targetFile);
                  }else{
                     $fileContents = file_get_contents($sourceFile);
                     file_put_contents($targetFile,$fileContents);
                  }
           
               }
            }
            
         }else{
            if(is_file($source)){
            			$fileNam = basename($source);
                  $fileContents = file_get_contents($source);
                  file_put_contents($target."/".$fileNam,$fileContents);
            }
        
         }

         return true;
   }

//-------------

function imageUploadNote(){
	$fileOptions = $_POST['base'];
	$server = "public_html";
	$mainDomainServer = $_SERVER['SERVER_NAME'];
	$v = end(explode(",",$fileOptions));
	$decoded = base64_decode($v);
	$path = getcwd();
	$makePath =	explode($server,$path);
	$path = $makePath[0]."/".$server;
	$uploadDir = $path."/uploads";
	if(!is_dir($uploadDir)){
		mkdir($uploadDir);
	}
	$timespand = date("YmdHis");
	$namemaker = "uploads/".$timespand.".png";
	$name = "../".$namemaker;
	$url = $mainDomainServer."/".$namemaker;
	file_put_contents($name, $decoded);
	echo $url;
	
	die();
	return true;
}
add_action('wp_ajax_imageUploadNote', 'imageUploadNote');
add_action('wp_ajax_nopriv_imageUploadNote', 'imageUploadNote');

function folderBack(){
	$pathDir = getcwd();
	$path = $_POST['path'];
	$getServerName = "public_html"; // * remove (kim.com) ;
	$mainPathRefine = explode($getServerName,$pathDir);
	$pathEx = explode("/",$path);
		$removePath = $pathEx[count($pathEx)-1];
		$margePath;
		foreach($pathEx as $mar){
			if($removePath != $mar){
				if(count($pathEx) > 2 && strlen($margePath) > 1 && strlen($mar)>1){
					$margePath .= "/". $mar;
				}else{
					if(substr($margePath, -1) == "/"){
						$margePath .= $mar;
					}else{
							$margePath .= "/". $mar;
					}
					
				}	
			}
		}

		$mainPath = $mainPathRefine[0]."/".$getServerName."/"."NoteOpen/".$margePath;

		if(is_dir($mainPath)){
			echo $mainPath;
		}else{
			echo "NoPath";
		}
	die();
	return true;
}
add_action('wp_ajax_folderBack', 'folderBack');
add_action('wp_ajax_nopriv_folderBack', 'folderBack');


function getFileDownloadUrl(){
	$path =	getDownloadPath();
	echo $path;
	die();
	return true;

}
add_action('wp_ajax_getFileDownloadUrl', 'getFileDownloadUrl');
add_action('wp_ajax_nopriv_getFileDownloadUrl', 'getFileDownloadUrl');


function getDownloadPath(){
	global $current_user;
	$path = getcwd();
	$getServerName = "public_html"; // * remove (kim.com) 
	$userFolderName = $current_user->user_login;
	$mainDomainServer = $_SERVER['SERVER_NAME'];

	$makePath =	explode($getServerName,$path);
	$path = $makePath[0]."/".$getServerName;

	$mainFolder = $path ."/UsersNoteDownloads";
	if(!is_dir($mainFolder)){
		mkdir($mainFolder);
	}
	if(!is_dir($mainFolder."/".$userFolderName)){
		mkdir($mainFolder."/".$userFolderName);
		$mainFolder = $mainFolder."/".$userFolderName;
	}else{
		$mainFolder = $mainFolder."/".$userFolderName;
	}
	if(!is_dir($mainFolder."/download")){
		mkdir($mainFolder."/download");
	}
	if(is_file($mainFolder."/download/download.docx")){
		return $mainDomainServer."/UsersNoteDownloads/".$userFolderName."/download/download.docx";
	}
	return "NO_URL";

}

function downloadDocx(){

	global $current_user;
	$html = $_POST['html'];
	$userFolderName = $current_user->user_login;
	$pw = new \PhpOffice\PhpWord\PhpWord();
	$section = $pw->addSection();
	\PhpOffice\PhpWord\Shared\html::addHtml($section, $html);
	$pathMaker = getDownloadPath();
	$docxPath = "../UsersNoteDownloads/".$userFolderName."/download/download.docx";
	$pw->save($docxPath,"Word2007");
	die();
	return true;
}
add_action('wp_ajax_downloadDocx', 'downloadDocx');
add_action('wp_ajax_nopriv_downloadDocx', 'downloadDocx');

function createFile(){
	global $wpdb;
	$fileName = $_POST['name'];
	$NoteDB = "wp_notePath";
	$getPath = $wpdb -> get_results("SELECT * FROM $NoteDB WHERE id = 1");
	$path;

	foreach ($getPath as $data) {
		$path = $data->textPath;
	}
	if(strlen($path)>3){
		$path = $path;
	}else{
		$path = getMainPath();
	}
	
	if(is_dir($path)){
		$path = $path ."/".$fileName.".html";
	 file_put_contents($path,"");
	}else{
		$createPaths = explode("/",$path);
		$fileNameGet = $createPaths[count($createPaths)-1];
		$path = str_replace($fileNameGet,$fileName.".html",$path);
		file_put_contents($path,"");
	}

	die();
	return true;
}

add_action('wp_ajax_createFile', 'createFile');
add_action('wp_ajax_nopriv_createFile', 'createFile');

function createFolder(){
	global $wpdb;

	$folderName = $_POST['name'];
	$NoteDB = "wp_notePath";
	$getPath = $wpdb -> get_results("SELECT * FROM $NoteDB WHERE id = 1");
	$path;

	foreach ($getPath as $data) {
		$path = $data->textPath;
	}
	if(strlen($path)>3){
		$path = $path;
	}else{
		$path = getMainPath();
	}
	
	if(is_dir($path)){
		$path = $path ."/".$folderName;
		mkdir($path);
	}else{
		$createPaths = explode("/",$path);
		$fileNameGet = $createPaths[count($createPaths)-1];
		$path = str_replace($fileNameGet,$folderName,$path);
		mkdir($path);
	}

	die();
	return true;
}

add_action('wp_ajax_createFolder', 'createFolder');
add_action('wp_ajax_nopriv_createFolder', 'createFolder');


function openFolders(){
	$folder = $_POST['path'];
	getFolderAndFiles($folder);
	die();
	return true;
}

add_action('wp_ajax_openFolders', 'openFolders');
add_action('wp_ajax_nopriv_openFolders', 'openFolders');


function fetchFolderAndFiles(){
	global $current_user;
	$userFolderName = $current_user->user_login;
	$getFirstPath = $_POST["path"];
	$folder = getMainPath();
	if($getFirstPath != ""){
		$folder = $getFirstPath;
	}
	if(!is_dir($folder)){
		mkdir($folder);
		$folder = $mainFolder ."/".$userFolderName;
	}
	getFolderAndFiles($folder);
	die();
	return true;
}


function getMainPath(){
	global $current_user;
	$path = getcwd();
	$getServerName = "public_html"; // * remove (kim.com) 
	if(strpos($path,$getServerName) !== false){
		$makePath =	explode($getServerName,$path);
		$path = $makePath[0].$getServerName;
	}
	$mainFolder = $path ."/NoteOpen";
	if(!is_dir($mainFolder)){
		mkdir($mainFolder);
		$mainFolder = $path ."/NoteOpen";
	}
	$userFolderName = $current_user->user_login;
	$folder = $mainFolder ."/".$userFolderName;
	if(!is_dir($folder)){
	    mkdir($folder);
	}
	return $folder;
}

function getFolderAndFiles($path){
	$scanFiles = scandir($path);
	if(count($scanFiles)>2){
		$i = 0;
		$response = [];
		$listFile = [];
		$listFolder = [];
		foreach ($scanFiles as $value) {
			if($i != 0 && $i != 1){
				if(strpos($value, ".")){
					$nameFiles = explode(".",$value);
					$fileTime = date("m/d/y",filemtime($path."/".$value));
					$listDatas = ["file",$nameFiles[0],$path."/".$value, $fileTime];
					
					
					array_push($listFile,$listDatas); 
				}else{
					$listDatas = ["folder",$value,$path."/".$value];
					array_push($listFolder, $listDatas);
				}	
			}
			$i++;
		}
		array_push($response,  $listFolder);
		array_push($response,  $listFile);
		echo json_encode($response);
		setPat("");
	}else{
		$returnEmpty = ["empty"];
		echo json_encode($returnEmpty);
	}
}

add_action('wp_ajax_fetchFolderAndFiles', 'fetchFolderAndFiles');
add_action('wp_ajax_nopriv_fetchFolderAndFiles', 'fetchFolderAndFiles');

function getFileContents(){
	$path = $_POST['path'];
	$content = file_get_contents($path,false);
	 echo $content;
	 setPat($path);
	die();
	return true;
}
add_action('wp_ajax_getFileContents', 'getFileContents');
add_action('wp_ajax_nopriv_getFileContents', 'getFileContents');


function inFolders(){
	$path = $_POST['path'];
	 setPat($path);
	die();
	return true;
}
add_action('wp_ajax_inFolders', 'inFolders');
add_action('wp_ajax_nopriv_inFolders', 'inFolders');

function getPathName(){
	global $current_user;
	$userFolderName = $current_user->user_login;
	$path = $_POST['path'];
	$showPathUser = explode($userFolderName,$path);
	echo $userFolderName.$showPathUser[count($showPathUser)-1];
	die();
	return true;
}
add_action('wp_ajax_getPathName', 'getPathName');
add_action('wp_ajax_nopriv_getPathName', 'getPathName');

function setPat($path){
	global $wpdb;
	global $current_user;
	$userFolderName = $current_user->user_login;
	$NoteDB = "wp_notePath";
	$checkDB = $wpdb -> Query("SELECT * FROM $NoteDB");
	if(!$checkDB && is_bool($checkDB)){
	 	$wpdb->Query("CREATE TABLE $NoteDB(id INT(20) AUTO_INCREMENT, textPath TEXT, userName TEXT, PRIMARY KEY(id))");
	 	$wpdb -> insert(
            $NoteDB,
            [
               "textPath" =>  $path,
               "userName"=>$userFolderName
            ]
        );
    }else{
	    $result = $wpdb->get_results("SELECT * FROM $NoteDB WHERE userName = '$userFolderName'");
	    if(strlen($userFolderName)>=2){
	    if(count($result) == 0){
	    		$wpdb -> insert(
	            $NoteDB,
	            [
	               "textPath" =>  $path,
	               "userName"=>$userFolderName
	            ]
	        );
	    }else{
	    	 $id;
		    foreach($result as $rst){
		    	$id = $rst->id;
		    }
	    	$wpdb -> update(
	            $NoteDB,
	            [
	               "textPath" =>  $path,
	               "userName"=>$userFolderName
	            ],
	            [
	            	"id" => $id
	            ]
	        );
	    }}
   
    }

}
function isPathReady(){
	global $wpdb;
	global $current_user;
	$userFolderName = $current_user->user_login;
	$NoteDB = "wp_notePath";
	$getPath = $wpdb->get_results("SELECT * FROM $NoteDB WHERE userName = '$userFolderName'");
	$path;
	foreach ($getPath as $data) {
		$path = $data->textPath;
	}
	if(strlen($path) > 3){
		if(is_file($path)){
			$readyPath = ["ready", $path];
			echo json_encode($readyPath);
		}
		else{
			$readyPath = ["readyFolder", $path];
			echo json_encode($readyPath);
		}
	
	}else{
		$readyPath = ["nofld", $path];
		echo json_encode($readyPath);
	}
	die();
	return true;
}
add_action('wp_ajax_isPathReady', 'isPathReady');
add_action('wp_ajax_nopriv_isPathReady', 'isPathReady');




function saveFile(){
	global $wpdb;
	$getContent = $_POST['htmlData'];
	$fileName = $_POST['fileName'];
	$NoteDB = "wp_notePath";
	$getPath = $wpdb -> get_results("SELECT * FROM $NoteDB WHERE id = 1");
	$path;
	foreach ($getPath as $data) {
		$path = $data->textPath;
	}	
	if(strlen($path) > 3){
		$filePath;
		if(!is_dir($path)){
			$modifyPath = explode("/",$path);
			$fileNameGet = $modifyPath[count($modifyPath)-1];
			$filePath = str_replace($fileNameGet,$fileName.".html",$path);
		}else{
			$filePath = $path;
		}
		
		if(is_file($filePath)){
			$matchPath = ["replace",$filePath];
			echo json_encode($matchPath);
		}else{
			file_put_contents($filePath."/".$fileName.".html", $getContent);
			$matchPath = ["new",$filePath];
			echo json_encode($matchPath);
		}
		
	}else{
		$folderPath = getMainPath();
		$addPath = $folderPath."/".$fileName.".html";
		if(file_exists($addPath)){
			$matchPath = ["replace",$addPath];
			echo json_encode($matchPath);
		}else{
			file_put_contents($addPath, $getContent);
			$matchPath = ["new",$addPath];
			echo json_encode($matchPath);
		}
	}
	
	die();
	return true;
}
add_action('wp_ajax_saveFile', 'saveFile');
add_action('wp_ajax_nopriv_saveFile', 'saveFile');

function fileSaveConfirm(){
	$getContent = $_POST['htmlData'];
	$getPath = $_POST['path'];
	$getContent = stripcslashes($getContent);
	file_put_contents($getPath, $getContent);
	die();
	return true;
}
add_action('wp_ajax_fileSaveConfirm', 'fileSaveConfirm');
add_action('wp_ajax_nopriv_fileSaveConfirm', 'fileSaveConfirm');
