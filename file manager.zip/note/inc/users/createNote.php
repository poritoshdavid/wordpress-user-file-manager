<?php

?>
	<!--<div class="fileName"></div>-->
	<div style="margin:20vh auto;">
   	<div id="editor" class="pell"></div>
   	<div id="saveEditor">
   		<button class="saveFile" type="button">Save</button>
   	</div>
    <div id="folders" class="folder">
    	<div>
    		<div>
	    		<button id = "createNote" type="button">Create New Note</button>
	    		<button id = "createFolder" type="button">Create New Folder</button>
	    	</div>
    	</div>
      <div class="showDir">
        <p></p>
      </div>
      <div style="display: inline-block;" class="pst"></div>
    	<div id="fileAndFolder"></div>
    </div>   
    </div>
    <style type="text/css">
        .pell-content > img{
            height:250px;
            width:300px;
        }
        .pell-content > a{
            text-decoration: underline;
            color:red;
        }
        @media only screen and (max-width: 600px) {
         .itemFolder > div:nth-child(1){
             width:30% !important;
         }
         .itemFolder > .optionDown{
             width:22% !important;
         }
         .itemFolder > div > p, .itemFolder > div > h6{
             font-size:10px;
         }
         .itemFolder > div > span, .itemFolder > div >div> span, {
             font-size:20px;
         }
         .itemFolder > div > h5{
             font-size:12px;
         }
         .itemFolder > div > .downloadDoc{
             padding:0;
         }
         
         .itemMoveFolder > div > h5{
             font-size:12px;
         } 
         .itemMoveFolder > div > p{
             font-size:10px;
         } 
         
        }
            
        @media print{
            body{
              visibility: hidden;
            }
            
            
            .pell-content{
              visibility: visible !important;
              position: absolute;
              top: 0;
              left: 0;
            }
         
        }
    </style>
    <script>
     var editor = window.pell.init({
    element: document.getElementById("editor"),
    actions: ["bold", "italic", "underline", "paragraph", "heading1", "heading2", "heading3", "olist", "ulist", "link", "unlink", "image", "justifyLeft", "justifyRight", "justifyCenter", "justifyFull"],
    defaultParagraphSeparator: "p",
    onChange: function (e) {
       
        for (var r = document.getElementsByTagName("img"), o = 0; o < r.length; o++) r[o].style.removeProperty("font-family"), r[o].style.removeProperty("background-color"), r[o].style.removeProperty("font-size"), r[o].style.removeProperty("color");
    },
});
    </script> 

<?php








