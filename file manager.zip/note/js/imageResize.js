var editor = document.querySelector(".pell-content");
if (editor != null) {
    editor.addEventListener("mousemove", (e) => {
       var elma = jQuery(".pell-content").find("a");
       var elmImg = jQuery(".pell-content").find("img");
       var style = elmImg.attr("style");
       if(style == undefined){
           elmImg.css({"height":"fit-content","width":"300px"});
       }
       elma.css({"text-decoration":"underline","color":"#591441"});
       
        for (var k = 0; k < editor.childNodes.length; k++) {
            var nod = editor.childNodes[k];
            if (nod.nodeValue == null) {
              if(nod.nodeName == "P"){
                var rn = nod.classList;
                rn.forEach(function(item,i){
                 var gString = item.replaceAll('"', '');
                 var gString = gString.replaceAll('\\', '');
                 if(gString == "MsoListParagraph"){
                     nod.remove();
                 }
            
                 
                });
            
                }
                
            }
        }
    });
    editor.addEventListener("mouseover", e => {
    
        if (e.target.nodeName == "IMG") {
            var altDiv = document.createElement("div");
            altDiv.setAttribute("id", "imgSizingAlt");
            altDiv.style.width = "150px";
            altDiv.style.position = "fixed";
            altDiv.textContent = "Double click to resize";
          
          
              altDiv.style.left = '50%';
              altDiv.style.top = '30%';  
        
            
            altDiv.style.color= "red";
            altDiv.style.padding = "10px";
            altDiv.style.background = "#ccc"
            // document.body.append(altDiv);
            // setTimeout(function() {
            //     document.getElementById("imgSizingAlt").remove();
            // }, 500);
            e.target.addEventListener("dblclick", c => {
                var getAlert = document.querySelector(".alertBox");
                if (getAlert == null) {
                      var mobile = 'ontouchstart' in window;
                    var makeDiv = document.createElement('div');
                    var makeAnother = document.createElement('div');
                    var makeInput = document.createElement('input');
                    var makeInputs = document.createElement('input');
                    var makeCircleInput = document.createElement('input');
                    var buttonMarge = document.createElement('div');
                    var makeBtn = document.createElement('button');
                    var makeBtnCancel = document.createElement('button');


                    var makeForm = document.createElement('div');
                    var makeForm2 = document.createElement('div');
                    var makeHeight = document.createElement('div');
                    var makeWidth = document.createElement('div');
                    var makeCircle = document.createElement('div');
                    var makeFram = document.createElement('div');
                    var makePc = document.createElement('div');

                    //style
                    // makeDiv.style.display = "none";
                    makeDiv.style.background = "#F3F5F6";
                    makeDiv.style.color = "#000000";
                    makeDiv.style.border = "1px solid #aaa";
                    makeDiv.style.position = "fixed";
                    makeDiv.style.width = "300px";
                    // makeDiv.style.height = "150px";
                    if(!mobile){
                        makeDiv.style.left = "50%";
                    }
                    
                    makeDiv.style.top = "30%";
                    makeDiv.style.zIndex = "999";
                    makeDiv.style.marginLeft = "-100px";
                    makeDiv.style.padding = "10px 20px 10px";
                    makeDiv.style.boxSizing = "border-box";
                    makeDiv.style.textAlign = "center";
                    //--------
                    makeAnother.style.textAlign = 'center';
                    makeAnother.style.fontWeight = 'bold';
                    makeHeight.style.display = "inline-block";
                    makeInput.style.display = "inline-block";

                    makeForm.style.marginTop = "5px";
                    makeForm.style.marginBottom = "5px";
                    makeForm2.style.marginTop = "5px";
                    makeForm2.style.marginBottom = "5px";
                    makeWidth.style.display = "inline-block";
                    makeCircle.style.display = "inline-block";
                    makeCircleInput.style.display = "inline-block";

                    makePc.style.display = "inline-block";
                    makeCircleInput.style.width = "50px";

                    makeWidth.style.marginRight = "5px";
                    makeInputs.style.marginLeft = "5px";
                    makeHeight.style.marginRight = "5px";
                    makeInput.style.marginLeft = "5px";
                    buttonMarge.style.marginTop = "10px";
                    buttonMarge.style.marginBottom = "10px";
                    makeBtnCancel.style.marginRight = "5px";
                    makeCircle.style.marginRight = "5px";
                    makeCircleInput.style.marginRight = "5px";
                    makeCircleInput.style.marginLeft = "5px";
                    makePc.style.marginLeft = "5px";
                    makeBtn.style.marginLeft = "5px";

                    //add classes
                    makeDiv.classList.add("alertBox");
                    makeAnother.classList.add("message");
                    // makeBtn.classList.add("yes");
                    makeAnother.textContent = "Add Image Height & Width"
                    makeBtn.textContent = "Add";
                    makeBtnCancel.textContent = "Cancel";
                    makeCircle.textContent = "Image Circle";

                    makePc.textContent = "%";
                    makeHeight.textContent = "Height";
                    makeWidth.textContent = "Width";
                    makeBtn.classList.add("addSize");
                    makeBtnCancel.classList.add("cancelAlt");

                    //append
                    makeDiv.append(makeAnother);
                    // makeForm.append(makeHeight);
                    // makeForm.append(makeInput);
                    makeForm2.append(makeWidth);
                    makeForm2.append(makeInputs);
                    makeDiv.append(makeForm);
                    makeDiv.append(makeForm2);
                    makeFram.append(makeCircle);
                    makeFram.append(makeCircleInput);
                    makeFram.append(makePc);
                    makeDiv.append(makeFram);
                    buttonMarge.append(makeBtnCancel);
                    buttonMarge.append(makeBtn);
                    makeDiv.append(buttonMarge);



                    var getDiv = document.body.prepend(makeDiv);
                    getAlert = document.querySelector(".alertBox");



                    var getCancelAlt = document.querySelector(".cancelAlt")
                    var getSizeAdd = document.querySelector(".addSize")
                    getCancelAlt.addEventListener("click", c => {
                        getAlert.remove();
                    });
                    getSizeAdd.addEventListener("click", a => {
                        if (makeInputs.value != "" && makeInputs.value != "" && makeCircleInput.value == "") {
                            e.target.style.height = makeInput.value + "px";
                            e.target.style.width = makeInputs.value + "px";
                            getAlert.remove();
                        } else if (makeInputs.value != "" && makeInputs.value != "" && makeCircleInput.value != "") {
                            e.target.style.height = makeInput.value + "px";
                            e.target.style.width = makeInputs.value + "px";
                            e.target.style.borderRadius = makeCircleInput.value + '%';
                            getAlert.remove();
                        } else if (makeCircleInput.value != "") {
                            e.target.style.borderRadius = makeCircleInput.value + '%';
                            getAlert.remove();
                        }
                    });
                }
            });
        }
    });
}